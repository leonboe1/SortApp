//
//  SelectionSort.swift
//  SortingAlgorithmsPlayground
//
//  Created by Leon Böttger on 14.04.22.
//

import Foundation


extension Model {
    
    /// performs modified selection sort on arrToSort
    public func selectionSort() {
        
        arrToSort = arr
        
        for i in 0 ..< arrToSort.count - 1 {
            
            var minIndex = i
            
            arrToSort[minIndex].isCompared = true
            
            sleep(algorithm: .SelectionSort)
            
            for j in i+1 ..< arrToSort.count {
                
                arrToSort[j].isCompared = true
                
                /// flag to indicate that min index changed
                var flag = false
                
                if arrToSort[j] < arrToSort[minIndex] {
                    arrToSort[minIndex].isCompared = false
                    minIndex = j
                    arrToSort[minIndex].isCompared = true
                    flag = true
                }
                
                sleep(algorithm: .SelectionSort)
                
                // if min index did not change, current element is bigger and not compared anymore
                if(!flag) {
                    arrToSort[j].isCompared = false
                }
            }
            
            arrToSort[minIndex].isCompared = false
            arrToSort[minIndex].isEnabled = false
            arrToSort.swapAt(i, minIndex)
             
        }
        enableAll()
    }
}


