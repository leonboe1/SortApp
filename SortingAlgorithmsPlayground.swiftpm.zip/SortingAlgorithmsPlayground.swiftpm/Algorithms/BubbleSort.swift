//
//  BubbleSort.swift
//  SortingAlgorithmsPlayground
//
//  Created by Leon Böttger on 14.04.22.
//

import Foundation
import SwiftUI

extension Model {
    
    /// performs modified bubble sort on arrToSort
    public func bubbleSort() {
        
        arrToSort = arr
        
        guard arrToSort.count > 1 else {return}
        
        for i in 0..<arrToSort.count {
            for j in 0..<arrToSort.count-i-1 {
                
                arrToSort[j].isCompared = true
                arrToSort[j+1].isCompared = true
                
                sleep(algorithm: .BubbleSort)
                
                if arrToSort[j].value > arrToSort[j + 1].value {
                    
                    arrToSort.swapAt(j + 1, j)
                    
                    sleep(algorithm: .BubbleSort)
                }
                
                arrToSort[j].isCompared = false
                arrToSort[j+1].isCompared = false
            }

            arrToSort[arrToSort.count-i-1].isEnabled = false
            sleep(algorithm: .BubbleSort)
        }
        
        sleep(algorithm: .BubbleSort)
        
        enableAll()
    }
    
    /// makes execution slower on algorithm-specific thread
    func sleep(algorithm: SortAlgorithm) {
        // stop request -> finish immediately
        if(!stopRequest) {
            
            let delay = Settings.sharedInstance.delay
            var mul: Double = 1
            
            switch algorithm {
            case .BubbleSort:
                mul = 0.6
            case .InsertionSort:
                mul = 0.7
            case .SelectionSort:
                mul = 0.7
            case .QuickSort:
                mul = 1
            }
            
            usleep(UInt32(delay * mul))
        }
    }
}


