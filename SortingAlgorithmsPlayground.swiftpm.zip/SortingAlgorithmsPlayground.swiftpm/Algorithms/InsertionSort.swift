//
//  InsertionSort.swift
//  SortingAlgorithmsPlayground
//
//  Created by Leon Böttger on 14.04.22.
//

import Foundation

extension Model {
    
    /// performs modified insertion sort on arrToSort
    public func insertionSort() {
        
        arrToSort = arr
        
        arrToSort[0].isEnabled = false
        
        for index in 1..<arrToSort.count {
            var currentIndex = index
            
            arrToSort[currentIndex].isCompared = true
            arrToSort[currentIndex-1].isCompared = true
            
            // mark if any swap made for visualization
            var didRun = false
            
            while(currentIndex > 0 && arrToSort[currentIndex].value < arrToSort[currentIndex - 1].value) {
                
                didRun = true
                
                arrToSort[currentIndex].isCompared = true
                arrToSort[currentIndex-1].isCompared = true
                
                sleep(algorithm: .InsertionSort)
                
                arrToSort.swapAt(currentIndex - 1, currentIndex)
                currentIndex -= 1
                
                sleep(algorithm: .InsertionSort)
                
                arrToSort[currentIndex].isCompared = false
                arrToSort[currentIndex+1].isCompared = false
            }
            
            // if no swap made, we wait and also need to disable the comparison flag of the previous entry
            if(!didRun) {
                sleep(algorithm: .InsertionSort)
                arrToSort[currentIndex-1].isCompared = false
            }
            
            arrToSort[currentIndex].isCompared = false
            
            arrToSort[currentIndex].isEnabled = false
            
            sleep(algorithm: .InsertionSort)
        }
        
        enableAll()
    }
}
