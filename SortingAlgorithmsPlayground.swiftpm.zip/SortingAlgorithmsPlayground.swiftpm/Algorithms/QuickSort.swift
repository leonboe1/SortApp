//
//  QuickSort.swift
//  SortingAlgorithmsPlayground
//
//  Created by Leon Böttger on 14.04.22.
//

import Foundation

extension Model {
    
    /// performs modified quick sort on arrToSort
    public func quickSort() {
        
        arrToSort = arr
        
        let qsArr = arrToSort
        
        quicksort(qsArr, start: 0, stop: qsArr.count)
        
        /// quick sort modified with range for visualization: start inclusive, stop exclusive
        func quicksort(_ a: [SortElem], start: Int, stop: Int) {
            
            guard a.count > 1 else { return }
            
            // Select subrange
            for i in 0..<start {
                arrToSort[i].isEnabled = false
            }
            for i in stop..<arrToSort.count {
                arrToSort[i].isEnabled = false
            }
            
            sleep(algorithm: .QuickSort)
            
            let pivot = a[a.count/2]
            let less = a.filter { $0 < pivot }
            let equal = a.filter { $0 == pivot }
            let greater = a.filter { $0 > pivot }
            
            let leftStart = start
            let leftStop = start + less.count
            let rightStart = stop - greater.count
            let rightStop = stop
            
            // select pivot in full array
            arrToSort[start + a.count/2].isCompared = true
            
            sleep(algorithm: .QuickSort)
            
            var tempArray = arrToSort
            
            tempArray.replaceSubrange(leftStart..<leftStop, with: less)
            tempArray.replaceSubrange(leftStop..<rightStart, with: equal)
            
            // re-enable pivot -> can only be one element here
            tempArray[leftStop].isCompared = true
            tempArray.replaceSubrange(rightStart..<rightStop, with: greater)
            
            // something changed, wait
            if(arrToSort != tempArray) {
                arrToSort = tempArray
                sleep(algorithm: .QuickSort)
            }
            
            enableAll()
            
            // disable pivot
            arrToSort[leftStop].isCompared = false
            
            // recursion
            quicksort(less, start: leftStart, stop: leftStop) // left
            quicksort(greater, start: rightStart, stop: rightStop) // right
        }
    }
    
    /// enable all elements in array
    func enableAll() {
        for i in 0..<arrToSort.count {
            arrToSort[i].isEnabled = true
        }
    }
    
    /// remove compare flag of all elements in array
    func removeCompareFlag() {
        for i in 0..<arrToSort.count {
            arrToSort[i].isCompared = false
        }
    }
}
