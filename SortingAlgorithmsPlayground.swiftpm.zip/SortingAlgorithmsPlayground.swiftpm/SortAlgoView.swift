//
//  SortAlgoView.swift
//  SortingAlgorithmsPlayground
//
//  Created by Leon Böttger on 14.04.22.
//

import SwiftUI

struct SortAlgoView: View {
    
    @StateObject var model = Model()
    let sortAlgorithm: SortAlgorithm
    @ObservedObject var settings = Settings.sharedInstance
    @Environment(\.colorScheme) private var colorScheme
    
    var body: some View {
        
        GeometryReader { geo in
            
            ScrollView {
                VStack {
                    
                    let defaultWidth: CGFloat = CGFloat(model.arr.count * 2) * Constants.rectWidth
                    let space = geo.size.width - 50 //50 for left/right padding
                    
                    let scale: CGFloat = max(0, defaultWidth <= space ? 1 : space/(defaultWidth))
                    
                    let width = Constants.rectWidth * scale
                    let smaller: CGFloat = width * 0.6
                    
                    HStack(spacing: width) {
                        ForEach(model.arr) { elem in
                            
                            Rectangle()
                                .foregroundColor(.accentColor)
                                .frame(width: width, height: CGFloat(elem.value) * width)
                                .cornerRadius(5)
                                .overlay(Rectangle()
                                    .foregroundColor(colorScheme == .light ? .white : .black)
                                    .frame(width: width - smaller, height: CGFloat(elem.value) * width - smaller)
                                    .cornerRadius(5)
                                    .opacity( elem.isCompared ? 1 : 0)
                                )
                                .opacity(elem.hasSolidColor ? 1 : 0.6)
                        }.animation(.spring(), value: model.arr)
                    }
                    .padding()
                    
                    Group {
                        
                        HStack(spacing: 30) {
                            
                            LargeButton(imageName: "arrow.right.arrow.left", description: "Sort!", action: sort)
                            
                            LargeButton(imageName: "shuffle", description: "Shuffle!") {
                                if(model.sorting) {
                                    model.stopRequest = true
                                }
                                else {
                                    model.stopRequest = false
                                    model.randomData()
                                }
                            }
                            
                        }
                        .padding()
                        
                        HStack {
                            
                            Image(systemName: "tortoise.fill")
                                .foregroundColor(.gray)
                            
                            let binding = Binding {
                                Constants.minDelay + Constants.maxDelay - settings.delay
                            } set: { val in
                                settings.delay = Constants.minDelay + Constants.maxDelay - val
                            }
                            
                            Slider(value: binding, in: Constants.minDelay...Constants.maxDelay, step: 1)
                            
                            Image(systemName: "hare.fill")
                                .foregroundColor(.gray)
                        } .frame(maxWidth: Constants.maxWidth)
                            .padding()
                    }
                    
                    Divider()
                    
                    Text((sortAlgorithm.rawValue + "Desc").localized())
                        .foregroundColor(.primary.opacity(0.8))
                        .padding()
                    
                    Divider()
                    
                    Text((sortAlgorithm.rawValue + "Code").localized())
                        .foregroundColor(.primary.opacity(0.8))
                        .font(.system(.body, design: .monospaced))
                        .padding()
                    
                    Divider()
                    
                    Text("Want to learn another algorithm? See more on the app's start page.")
                        .foregroundColor(.primary.opacity(0.8))
                        .padding()
                        .padding(.bottom)
                    
                }
                .frame(maxWidth: Constants.maxWidth)
                .frame(maxWidth: .infinity)
                
                .padding(.horizontal)
            }
            .navigationBarTitle(sortAlgorithm.rawValue)
        }
    }
    
    func sort() {
        
        if(!model.sorting) {
            withAnimation {
                model.sorting = true
            }
            
            DispatchQueue(label: sortAlgorithm.rawValue).async { [self] in
                
                switch sortAlgorithm {
                case .BubbleSort:
                    model.bubbleSort()
                case .QuickSort:
                    model.quickSort()
                case .InsertionSort:
                    model.insertionSort()
                case .SelectionSort:
                    model.selectionSort()
                }
                
                DispatchQueue.main.async {
                    withAnimation {
                        model.sorting = false
                    }
                }
            }
        }
    }
}

extension String{
    func localized() -> String {
        let localizedString = NSLocalizedString(self, comment: "")
        return localizedString
    }
}

struct Previews_SortAlgoView_Previews: PreviewProvider {
    static var previews: some View {
        SortAlgoView(sortAlgorithm: .BubbleSort)
    }
}
