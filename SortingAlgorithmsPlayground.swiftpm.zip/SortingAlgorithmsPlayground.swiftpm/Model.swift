//
//  Model.swift
//  SortingAlgorithmsPlayground
//
//  Created by Leon Böttger on 14.04.22.
//

import Foundation
import SwiftUI

/// shared settings between algorithms
public class Settings: ObservableObject {
   
    /// singleton for Settings
    static var sharedInstance = Settings()
    
    private init(){}
    
    /// delay between algorithm operations in us
    @Published public var delay: Double = (Constants.maxDelay - Constants.minDelay) * 0.5 + Constants.minDelay
}

/// model for each algorithm
public class Model: ObservableObject {
    
    public init() {
        randomData()
    }
    
    /// signals if algorithm should stop
    var stopRequest = false
    
    /// array to be displayed
    @Published public var arr = (1..<Constants.elemCount).map { i in SortElem(value: i) }
    
    /// an algorithm is running
    @Published var sorting = false {
        didSet {
            
            if(!sorting && stopRequest) {
                DispatchQueue.main.asyncAfter(deadline: .now()) { [self] in
                    
                    stopRequest = false
                    randomData()
                }
            }
        }
    }
    
    /// array to be sorted, changes array to be displayed
    var arrToSort = [SortElem]() {
        didSet {
            DispatchQueue.main.async { [self] in
                arr = arrToSort
            }
        }
    }
    
    /// shuffles array
    public func randomData() {
        arr.shuffle()
    }
}


public struct Constants {
    
    /// how large the array should be
    public static var elemCount: Int {
        min(20, maxCount)
    }
    
    /// max value for speed slider
    public static let maxDelay: Double = 1000000
    
    /// min value for speed slider
    public static let minDelay: Double = 10000
    
    /// corner radius for labels
    static let cornerRadius: CGFloat = 10
    
    /// height of buttons and labels
    static let labelHeight: CGFloat = 60
    
    /// max width of content
    static let maxWidth: CGFloat = 600
    
    /// default width of rectangles representing array entries
    static let rectWidth: CGFloat = 10
    
    /// maximum count for array based on screen
    static var maxCount: Int {
        Int(min(UIScreen.main.bounds.width, UIScreen.main.bounds.height) / (Constants.rectWidth*2))
    }
}

/// array element
public struct SortElem: Identifiable, Equatable, Comparable {
    public static func < (lhs: SortElem, rhs: SortElem) -> Bool {
        lhs.value < rhs.value
    }
    
    /// value to sort
    public let value: Int
    
    /// algorithm compares current element
    public var isCompared = false
    
    /// if element should be shown without transparecy
    public var hasSolidColor: Bool {
        isCompared ? true : isEnabled
    }
    
    /// is currently relevant for algorithm
    public var isEnabled = true
    
    /// identifier for animation
    public let id = UUID()
}


/// all algorithms available
enum SortAlgorithm: String, CaseIterable {
    case BubbleSort
    case InsertionSort
    case SelectionSort
    case QuickSort
}
