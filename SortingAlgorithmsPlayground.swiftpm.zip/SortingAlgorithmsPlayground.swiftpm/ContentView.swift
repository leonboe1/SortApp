//
//  ContentView.swift
//  SortingAlgorithmsPlayground
//
//  Created by Leon Böttger on 14.04.22.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var settings = Settings.sharedInstance
    @State var showFirst = false
    
    var body: some View {
        
        NavigationView {
            ScrollView {
                VStack(spacing: 15) {
                    
                    Text("Want to learn sorting algorithms interactively? Click on a button below to learn more about the algorithm and to see it in action!")
                        .foregroundColor(.white)
                        .padding(.vertical)
                        .modifier(FieldModifier(color: .blue))
                    
                    Divider()
                    
                    ForEach(SortAlgorithm.allCases, id: \.self) { algo in
                        
                        NavigationLink {
                            SortAlgoView(sortAlgorithm: algo)
                        } label: {
                            AlgorithmOverviewView(algo: algo)
                        }
                        
                    }
                    .onAppear{
                        if(isiPad()) {
                            showFirst = true
                        }
                    }
                    
                    Divider()
                    
                    Text("Thanks to https://github.com/raywenderlich/swift-algorithm-club (MIT Licence)")
                }
                .frame(maxWidth: Constants.maxWidth)
                .padding(.horizontal)
                .padding(.top)
            }
            .navigationBarTitle("SortingApp")
            
            SortAlgoView(sortAlgorithm: .BubbleSort)
        }
    }
}


/// returns is device is an iPad
func isiPad() -> Bool {
    let device = UIDevice.current
    
    let iPad = device.model == "iPad"
    
    return iPad
}


/// adds rounded rectangle to content
struct FieldModifier: ViewModifier {
    var color = Color("AltColor")
    
    func body(content: Content) -> some View {
        content
            .frame(minHeight: Constants.labelHeight)
            .padding(.horizontal)
            .background(color.cornerRadius(Constants.cornerRadius))
    }
}


/// navigation link to algorithm
struct AlgorithmOverviewView: View {
    
    let algo: SortAlgorithm
    
    var body: some View {
        
        HStack {
            Text(algo.rawValue)
                .foregroundColor(.primary.opacity(0.8))
            Spacer()
            Image(systemName: "chevron.right")
        }
        
        .modifier(FieldModifier())
        
    }
}
